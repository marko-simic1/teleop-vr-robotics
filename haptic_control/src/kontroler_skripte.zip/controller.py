#!/usr/bin/env python3

import rospy
import numpy as np
from geometry_msgs.msg import PoseStamped, Vector3, Pose, Point, Quaternion, WrenchStamped 
from omni_msgs.msg import OmniFeedback, OmniButtonEvent
from tf.transformations import quaternion_inverse, quaternion_multiply, euler_from_quaternion

class Controller:
    def __init__(self):
        rospy.init_node('Controller')

        # Subscribers
        self.haptic_pose_sub = rospy.Subscriber('/touch/stylus_pose', PoseStamped, self.pose_callback)

        # Publishers
        self.relative_transform_pub = rospy.Publisher('/robot_arm/relative_pose_command', PoseStamped, queue_size=10)

        self.last_pose = None

        rospy.loginfo("Controller node ready.")

    def pose_callback(self, msg):
        if self.last_pose == None:
            self.last_pose = msg.pose
            rospy.loginfo(f"  last_pose: {msg.pose}")
        else:
            pose1 = self.last_pose
            pose2 = msg.pose
            
            translation = self.get_translation_diff(pose1, pose2)
            rotation_quat = self.get_rotation_diff(pose1, pose2)
            rotation_rpy = self.get_rotation_diff_euler(pose1, pose2)

            rospy.loginfo(f"  Translation difference: {translation}")
            rospy.loginfo(f"  Rotation difference (quaternion): {rotation_quat}")
            rospy.loginfo(f"  Rotation difference (RPY): {rotation_rpy}")

            self.transform_publisher(translation, rotation_quat, msg.header)

            self.last_pose = msg.pose

    def transform_publisher(self, translation, rotation_quat, header):
        relative_transform_msg = PoseStamped()
        relative_transform_msg.header = header

        relative_transform_msg.pose.position.x = translation[0]
        relative_transform_msg.pose.position.y = translation[1]
        relative_transform_msg.pose.position.z = translation[2]

        relative_transform_msg.pose.orientation.x = rotation_quat[0]
        relative_transform_msg.pose.orientation.y = rotation_quat[1]
        relative_transform_msg.pose.orientation.z = rotation_quat[2]
        relative_transform_msg.pose.orientation.w = rotation_quat[3]
            
        self.relative_transform_pub.publish(relative_transform_msg)
        rospy.loginfo("Published relative translation and rotation.")
        
    def get_translation_diff(self, pose1, pose2):
        p1 = np.array([pose1.position.x, pose1.position.y, pose1.position.z])
        p2 = np.array([pose2.position.x, pose2.position.y, pose2.position.z])

        return p2 - p1
    
    def get_rotation_diff(self, pose1, pose2): 
        q1 = [pose1.orientation.x, pose1.orientation.y, pose1.orientation.z, pose1.orientation.w]
        q2 = [pose2.orientation.x, pose2.orientation.y, pose2.orientation.z, pose2.orientation.w]

        q1_inv = quaternion_inverse(q1)
        q_rel = quaternion_multiply(q2, q1_inv)  # rotation from pose1 to pose2

        return q_rel # quaternion
    
    def get_rotation_diff_euler(self, pose1, pose2):
        q_rel = self.get_rotation_diff(pose1, pose2)
        return euler_from_quaternion(q_rel)  # returns (roll, pitch, yaw)


if __name__ == '__main__':
    try:
        controller = Controller()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass