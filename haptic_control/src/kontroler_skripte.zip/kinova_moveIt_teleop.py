#!/usr/bin/env python3

import sys
import time
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_srvs.srv import Empty
import numpy as np
from tf.transformations import quaternion_multiply, quaternion_from_euler

class KinovaMoveItTeleop(object):
    """
    KinovaMoveItTeleop: Controls the Kinova robotic arm using relative pose commands
    received from a haptic controller (e.g., your Controller script).
    It subscribes to a PoseStamped topic and applies the received
    translation and rotation as deltas to the robot's current end-effector pose.
    """
    def __init__(self):
        # Initialize MoveIt Commander and ROS node
        super(KinovaMoveItTeleop, self).__init__()
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('kinova_moveit_teleop', anonymous=True)

        # Retrieve parameters from the ROS parameter server
        # These parameters are typically set by the Kortex driver or robot launch files
        try:
            self.is_gripper_present = rospy.get_param(rospy.get_namespace() + "is_gripper_present", False)
            if self.is_gripper_present:
                gripper_joint_names = rospy.get_param(rospy.get_namespace() + "gripper_joint_names", [])
                self.gripper_joint_name = gripper_joint_names[0]
            else:
                self.gripper_joint_name = ""
            self.degrees_of_freedom = rospy.get_param(rospy.get_namespace() + "degrees_of_freedom", 7)

            # Define the MoveIt group names (e.g., "arm" for the robotic arm)
            arm_group_name = "arm"
            # Initialize RobotCommander, Scene, and MoveGroupCommander
            self.robot = moveit_commander.RobotCommander("robot_description")
            self.scene = moveit_commander.PlanningSceneInterface(ns=rospy.get_namespace())
            self.arm_group = moveit_commander.MoveGroupCommander(arm_group_name, ns=rospy.get_namespace())

            # Publisher for displaying planned trajectories (useful for debugging)
            self.display_trajectory_publisher = rospy.Publisher(
                rospy.get_namespace() + 'move_group/display_planned_path',
                moveit_msgs.msg.DisplayTrajectory,
                queue_size=20
            )

            # If a gripper is present, initialize its MoveGroupCommander
            if self.is_gripper_present:
                gripper_group_name = "gripper"
                self.gripper_group = moveit_commander.MoveGroupCommander(gripper_group_name, ns=rospy.get_namespace())

            rospy.loginfo("Initializing Kinova MoveIt Teleop node in namespace " + rospy.get_namespace())

            # Subscriber for relative pose commands from the haptic controller
            # This is the core of the teleoperation logic
            self.relative_transform_sub = rospy.Subscriber(
                '/robot_arm/relative_pose_command',
                geometry_msgs.msg.PoseStamped,
                self.relative_pose_callback,
                queue_size=1
            )

            # Flag to indicate if the MoveIt interface is successfully initialized
            self.is_init_success = True
            rospy.loginfo("Kinova MoveIt Teleop node ready. Waiting for commands...")

        except Exception as e:
            rospy.logerr(f"Failed to initialize KinovaMoveItTeleop: {e}")
            self.is_init_success = False

        # Parameters for scaling the incoming deltas (adjust these for sensitivity)
        # 0.001 converts mm to meters if your haptic device reports in mm
        # Adjust these values based on desired sensitivity
        self.translation_scale = 1.0  # e.g., 0.001 for mm to meters, or just sensitivity
        self.rotation_scale = 1.0     # e.g., 0.1 for less sensitive rotation, or just sensitivity

        # Add a flag to prevent rapid command flooding if the callback rate is very high
        self.is_moving = False
        self.last_move_time = rospy.Time.now()
        self.min_move_interval = rospy.Duration(0.05) # Minimum time between move commands (50ms)


    def relative_pose_callback(self, msg):
        """
        Callback function for incoming relative pose commands.
        Calculates the new target pose for the robot based on its current pose
        and the received relative transformation.
        """
        if not self.is_init_success:
            rospy.logwarn("MoveIt interface not initialized. Skipping relative pose command.")
            return

        # Simple rate limiting to prevent overwhelming MoveIt
        if (rospy.Time.now() - self.last_move_time) < self.min_move_interval:
            return
        
        # Get the current end-effector pose of the robot
        current_robot_pose = self.arm_group.get_current_pose().pose

        # Extract relative translation and rotation from the received message
        delta_x = msg.pose.position.x * self.translation_scale
        delta_y = msg.pose.position.y * self.translation_scale
        delta_z = msg.pose.position.z * self.translation_scale

        delta_quat = [msg.pose.orientation.x * self.rotation_scale,
                      msg.pose.orientation.y * self.rotation_scale,
                      msg.pose.orientation.z * self.rotation_scale,
                      msg.pose.orientation.w] # W component should usually not be scaled if it's a rotation quaternion


        # IMPORTANT: If your haptic device's quaternion represents a true delta
        # and not a small angle approximation, you might not want to scale x,y,z components directly.
        # For small rotations, scaling x,y,z (which are related to axis * sin(angle/2)) can work,
        # but for larger deltas or more accurate control, you might want to scale the Euler angles
        # derived from the delta quaternion, then convert back to quaternion.
        # For now, we'll assume the given delta_quat is already a small enough rotation.
        # Alternatively, if the haptic controller is giving RPY differences, convert those to a quaternion
        # and then scale the RPY values.

        # Let's adjust the delta_quat scaling for clarity and common practice:
        # If the haptic controller provides a small relative rotation quaternion,
        # the simplest approach is to use quaternion_multiply.
        # The rotation_scale will then affect the 'magnitude' of the rotation, if delta_quat is not normalized
        # or if you intend to reduce its effect.
        # A more robust way to scale rotation would be to convert to axis-angle, scale the angle, then back to quaternion.
        # Or, scale the RPY values if your haptic device reports them, then convert to quaternion.
        # For now, we'll keep the direct quaternion multiply with a scale on x,y,z which works for small changes.
        # Ensure the `w` component is handled correctly (often not scaled or recalculated).
        # A common mistake is to scale the quaternion components directly which can make it non-unit.
        # Let's assume the incoming `msg.pose.orientation` is already a *relative rotation* quaternion.
        # To scale it, we can convert it to axis-angle, scale the angle, then convert back.
        # For simplicity and given the user's current script structure, we'll assume the provided
        # `rotation_quat` in `Controller.py` is a small delta and apply it.
        # If rotation_scale is used, it should be applied to a derived angle or RPY values.
        # For now, we'll apply it directly to the XYZ components for a simple effect,
        # but warn about proper quaternion scaling if issues arise.
        
        # Calculate new position
        target_position = geometry_msgs.msg.Point()
        target_position.x = current_robot_pose.position.x + delta_x
        target_position.y = current_robot_pose.position.y + delta_y
        target_position.z = current_robot_pose.position.z + delta_z

        # Calculate new orientation using quaternion multiplication
        # new_q = delta_q * current_q (order matters)
        # tf.transformations.quaternion_multiply(q1, q2) calculates q1 * q2
        current_orientation_quat = [current_robot_pose.orientation.x,
                                    current_robot_pose.orientation.y,
                                    current_robot_pose.orientation.z,
                                    current_robot_pose.orientation.w]
        
        # The incoming delta_quat from the Controller is q_rel = q_haptic_current * q_haptic_previous_inv
        # To apply this delta to the robot's current orientation, we do:
        # target_orientation = quaternion_multiply(delta_quat, current_orientation_quat)
        # Note: If the scaling factor for rotation is applied to the raw quaternion components,
        # the resulting delta_quat might not be a unit quaternion.
        # For more robust scaling of rotation, consider converting delta_quat to Euler angles,
        # scaling the Euler angles, and then converting back to a quaternion.
        
        # Example of scaling Euler angles (if you want to implement this for better control):
        # r, p, y = euler_from_quaternion(delta_quat_from_msg)
        # scaled_delta_quat = quaternion_from_euler(r * self.rotation_scale, p * self.rotation_scale, y * self.rotation_scale)
        # target_orientation_quat = quaternion_multiply(scaled_delta_quat, current_orientation_quat)
        
        # For now, applying the original delta_quat without explicit scaling here,
        # assuming the scaling is handled in the Controller or that direct quaternion delta works for small changes.
        # If scaling is applied in Controller, ensure the resulting quaternion is normalized before sending.
        # Let's re-normalize the incoming delta_quat just in case it's not perfectly unit.
        norm_delta_quat = np.array([msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w])
        norm_delta_quat = norm_delta_quat / np.linalg.norm(norm_delta_quat) # Normalize the incoming delta quaternion

        # Apply the normalized relative rotation
        target_orientation_quat = quaternion_multiply(norm_delta_quat, current_orientation_quat)

        # Construct the new target pose message
        target_pose = geometry_msgs.msg.Pose()
        target_pose.position = target_position
        target_pose.orientation.x = target_orientation_quat[0]
        target_pose.orientation.y = target_orientation_quat[1]
        target_pose.orientation.z = target_orientation_quat[2]
        target_pose.orientation.w = target_orientation_quat[3]

        rospy.loginfo(f"Moving robot to target pose: Position({target_pose.position.x:.3f}, {target_pose.position.y:.3f}, {target_pose.position.z:.3f})")
        rospy.loginfo(f"                          Orientation({target_pose.orientation.x:.3f}, {target_pose.orientation.y:.3f}, {target_pose.orientation.z:.3f}, {target_pose.orientation.w:.3f})")
        
        # Command MoveIt to move to the new target pose
        success = self.go_to_pose(target_pose)
        if success:
            self.last_move_time = rospy.Time.now()
        else:
            rospy.logwarn("Failed to plan or execute movement to target pose.")

    def go_to_pose(self, pose):
        """
        Plans and executes a movement to a specified Cartesian pose.
        """
        self.arm_group.set_pose_target(pose)
        
        # Use arm_group.go(wait=False) for continuous movement
        # This means the planning and execution is non-blocking.
        # If wait=True, each small move would block until completion, leading to choppy motion.
        success = self.arm_group.go(wait=False)
        self.arm_group.stop() # Stop any remaining movement
        self.arm_group.clear_pose_targets() # Clear previously set pose targets
        return success

    # You can keep other functions from the example if you want to use them for
    # initial setup or specific maneuvers, e.g., reach_named_position, reach_gripper_position.
    def reach_named_position(self, target):
        arm_group = self.arm_group
        rospy.loginfo("Going to named target " + target)
        arm_group.set_named_target(target)
        (success_flag, trajectory_message, planning_time, error_code) = arm_group.plan()
        return arm_group.execute(trajectory_message, wait=True)

    def get_cartesian_pose(self):
        """
        Gets and logs the current end-effector Cartesian pose.
        """
        pose = self.arm_group.get_current_pose()
        rospy.loginfo("Actual cartesian pose is : ")
        rospy.loginfo(pose.pose)
        return pose.pose

def main():
    # Create an instance of the KinovaMoveItTeleop controller
    teleop_controller = KinovaMoveItTeleop()

    if teleop_controller.is_init_success:
        # Optional: Move the arm to a safe "home" position at startup
        # teleop_controller.reach_named_position("home") # Uncomment if you have a "home" named target

        # Keep the node running, waiting for incoming relative pose commands
        rospy.spin()
    else:
        rospy.logerr("Kinova MoveIt Teleop node failed to initialize. Exiting.")

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

